// gist.github.com/Shiponkarmoker> header to fix function.js>counter.js



// misitup activation
var mixer = mixitup('.portfolioContent');
// portfolio popup
$(document).ready(function() {
  $('.portfolio_popup_img_link').magnificPopup({type:'image'});
});
// Owl carousel activation

// Team slider Owl carousel 
$(document).ready(function(){
	// $("owl").owlCarousel();
  $('.owl_carousel_team').owlCarousel(
  {
  	loop:true,
  	margin:10,
  	nav:true, //for left right arrow
  	items:5,
  	responsive:{
  		0:{
  			items:1
  		},600:{
  			items:1
  		},1000:{
  			items:4
  		}
  	}
  }
  );
});


// TESTIMONIAL slider Owl carousel 
$(document).ready(function(){
	// $("owl").owlCarousel();
  $('.owl_carousel_testimonial').owlCarousel(
  {
  	loop:true,
  	margin:10,
  	nav:true, //for left right arrow
  	items:1,
  	responsive:{
  		0:{
  			items:1
  		},600:{
  			items:1
  		},1000:{
  			items:1
  		}
  	}
  }
  );
});