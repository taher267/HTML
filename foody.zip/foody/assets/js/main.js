jQuery(document).ready(function() {

$('.heroActive').owlCarousel({
        loop:true,
        items:1,
        dots:false,
        autoplay:true,
        autoplaySpeed:2500,
      });


jQuery('.bgPlayBtn').magnificPopup({
	type:'iframe',
	iframe:{patterns:{youtube:{index:'youtube.com/',id:'v=',src:'https://www.youtube.com/embed/%id%?autoplay=1',}}, srcAction:'iframe_src',}
});

//iframe End===========================================




  // });\

// $('.bgPlayBtn').magnificPopup({tyle:'video',});


//  $('.solutionImgPop').magnificPopup({
//    type:'image',
// });



  //Owl Carousel Active


// Counterup Mission Vision

// $('.countingActive').counterUp({
//             delay: 10,
//             time: 1000
//         });





});


